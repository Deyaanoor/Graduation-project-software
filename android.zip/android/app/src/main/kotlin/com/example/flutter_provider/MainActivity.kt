package com.example.flutter_provider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
